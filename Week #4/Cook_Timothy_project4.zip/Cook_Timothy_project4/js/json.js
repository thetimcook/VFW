/*		JSON data

*/


var json = {
	"car1": {
		"make": 		["Make: ", "Porsche"],
		"model": 		["Model: ", "911"],
		"year": 		["Year: ", "2009"],
		"doors": 		["Number of doors: ", "2"],
		"colors": 		["Color: ", "Black"],
		"display": 		["What makes it stand out? ", ["Sound", "Fast", "Rims"]],
		"condition": 	["Condition: ", "Amazing"],
		"describe": 	["Describe the car in your own words. ", "I like it much."]
	},
	"car2": {
		"make": 		["Make: ", "Ferrari"],
		"model": 		["Model: ", "458"],
		"year": 		["Year: ", "2012"],
		"doors": 		["Number of doors: ", "2"],
		"colors": 		["Color: ", "Red"],
		"display": 		["What makes it stand out? ", ["Fast", "Rims"]],
		"condition": 	["Condition: ", "Amazing"],
		"describe": 	["Describe the car in your own words. ", "I like it muchly."]
	}


}